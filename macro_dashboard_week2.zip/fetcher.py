# =============================================================================
# data/fetcher.py
# Handles all data retrieval from FRED (Federal Reserve Economic Data).
#
# Key design decisions:
#   1. CACHING: Raw FRED responses are pickled to disk (.cache/).
#      Starts instantly after first run; won't hammer the API in development.
#   2. FORWARD FILL: FRED reports business days only. We ffill up to 5 days
#      so rolling windows are continuous across weekends/holidays.
#   3. GRACEFUL FAILURE: If a series fails, we log it and continue.
#      The dashboard still renders with whatever data came through.
# =============================================================================

import os
import pickle
import pandas as pd
from datetime import datetime, timedelta
from fredapi import Fred

from config import (
    FRED_API_KEY, RATE_SERIES, SPREAD_SERIES, CREDIT_SERIES,
    START_DATE, CACHE_DIR, CACHE_TTL_HOURS
)


# ── CACHE UTILITIES ───────────────────────────────────────────────────────────

def _cache_path(key: str) -> str:
    os.makedirs(CACHE_DIR, exist_ok=True)
    return os.path.join(CACHE_DIR, f"{key}.pkl")

def _cache_is_fresh(key: str) -> bool:
    path = _cache_path(key)
    if not os.path.exists(path):
        return False
    age = datetime.now() - datetime.fromtimestamp(os.path.getmtime(path))
    return age < timedelta(hours=CACHE_TTL_HOURS)

def _read_cache(key: str):
    with open(_cache_path(key), "rb") as f:
        return pickle.load(f)

def _write_cache(key: str, data) -> None:
    with open(_cache_path(key), "wb") as f:
        pickle.dump(data, f)

def clear_cache() -> None:
    import glob
    files = glob.glob(os.path.join(CACHE_DIR, "*.pkl"))
    for f in files:
        os.remove(f)
    print(f"  [cache] Cleared {len(files)} cached file(s).")


# ── FRED CONNECTION ───────────────────────────────────────────────────────────

def _get_fred() -> Fred:
    if not FRED_API_KEY or FRED_API_KEY == "YOUR_FRED_API_KEY_HERE":
        raise ValueError(
            "\n\n❌  No FRED API key found.\n"
            "    Get a free key at: https://fred.stlouisfed.org/docs/api/api_key.html\n"
            "    Then set it in config.py or as environment variable FRED_API_KEY.\n"
        )
    return Fred(api_key=FRED_API_KEY)


# ── GENERIC SERIES FETCHER ────────────────────────────────────────────────────

def _fetch_series_dict(
    series_dict: dict,
    cache_key: str,
    label: str,
    force: bool = False,
    ffill_limit: int = 5,
) -> pd.DataFrame:
    """
    Generic fetcher: given a {name: fred_id} dict, pulls each series,
    combines into a daily DataFrame, forward-fills, and caches.

    Used by all three fetch functions below — rates, spreads, credit —
    so any new panel just needs its series dict in config.py.
    """
    if not force and _cache_is_fresh(cache_key):
        print(f"  [cache] {label} loaded from cache.")
        return _read_cache(cache_key)

    print(f"  [FRED] Fetching {label}...")
    fred = _get_fred()

    frames = {}
    for name, series_id in series_dict.items():
        try:
            s = fred.get_series(series_id, observation_start=START_DATE)
            frames[name] = s
            print(f"    ✓ {name:<8s}  ({series_id})")
        except Exception as e:
            print(f"    ✗ {name:<8s}  ({series_id}) — {e}")

    df = pd.DataFrame(frames)
    df.index = pd.to_datetime(df.index)
    df = df.ffill(limit=ffill_limit).dropna(how="all")

    _write_cache(cache_key, df)
    if not df.empty:
        print(f"  [FRED] {label}: {df.shape[0]} rows × {df.shape[1]} cols  "
              f"({df.index[0].date()} → {df.index[-1].date()})")
    return df


# ── PUBLIC FETCH FUNCTIONS ────────────────────────────────────────────────────

def fetch_all_rates(force: bool = False) -> pd.DataFrame:
    """
    Treasury yields (3M/2Y/5Y/10Y/30Y) + Fed Funds Rate.
    Returns daily DataFrame, values in % (e.g. 4.5 = 4.5%).
    """
    return _fetch_series_dict(RATE_SERIES, "rates_v1", "Rates", force=force)


def fetch_spreads(force: bool = False) -> pd.DataFrame:
    """
    FRED pre-calculated yield curve spreads: T10Y2Y, T10Y3M.
    Returns daily DataFrame, values in % (multiply by 100 for bps).
    """
    return _fetch_series_dict(SPREAD_SERIES, "spreads_v1", "Spreads", force=force)


def fetch_credit(force: bool = False) -> pd.DataFrame:
    """
    ICE BofA credit spread indices + St. Louis Financial Stress Index.

    Columns: IG, HY, BBB, CCC (all OAS in %), STLFSI (index level)

    OAS (Option-Adjusted Spread) = the extra yield credit bonds pay over
    equivalent Treasuries, adjusted for any embedded options. It's the
    purest measure of credit risk premium the market is demanding.

    STLFSI > 0  → above-average financial stress
    STLFSI < 0  → below-average financial stress (loose conditions)

    Note: STLFSI is weekly (published Thursdays). The ffill fills in
    Mon–Wed of each week using the prior Thursday's reading — acceptable
    approximation for daily display.
    """
    return _fetch_series_dict(
        CREDIT_SERIES, "credit_v1", "Credit",
        force=force,
        ffill_limit=7,   # STLFSI is weekly so we need to fill up to 7 days
    )


# ── CONVENIENCE LOADER ────────────────────────────────────────────────────────

def load_all(force: bool = False) -> tuple:
    """
    Fetch all three datasets. Returns (rates_df, spreads_df, credit_df).

    This is the single call made at app startup and on Refresh.
    Force=True clears the disk cache first, triggering live FRED pulls.
    """
    if force:
        clear_cache()
    rates   = fetch_all_rates(force=force)
    spreads = fetch_spreads(force=force)
    credit  = fetch_credit(force=force)
    return rates, spreads, credit
